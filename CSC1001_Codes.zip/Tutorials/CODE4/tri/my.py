from MyTriangle import *
def my():
    print('call my')
    print(isValid(3,4,5))
