
print(int)

print(int(3.5))

int = 'int is now a string'

print(int)

print(int(3.5))
