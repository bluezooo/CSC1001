sumup = 0
num = 1

while num<=100:
    sumup += num
    num += 1

print('the sum from 1 to 100 is ', sumup)
