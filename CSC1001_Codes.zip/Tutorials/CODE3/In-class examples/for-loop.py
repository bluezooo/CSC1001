sumup = 0

for num in range(1, 101):
    sumup += num

print('the sum from 1 to 100 is ', sumup)
