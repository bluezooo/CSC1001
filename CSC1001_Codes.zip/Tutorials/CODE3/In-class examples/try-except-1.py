try:
    a = 2
    #b = 3
    print(a+b)
except:
    print('There are some errors in the try block.')
