try:
    num = int(input('Please input an integer:'))
    print(num)
except:
    print('Your input is not an integer.')
