class Person():
    name = "Tim"
    
class Animal(object):
    name = "Anaconda"
    

print(Person.__mro__)
print(Animal.__mro__)

