print('int')
a = 1

b = 1

c = a

print(id(a))
print(id(b))
print(id(c))

print('\nfloat')
a = 1.9

b = 1.9

c = a

print(id(a))
print(id(b))
print(id(c))

print('\nstring')
a = 'abc'

b = 'abc'

c = a

print(id(a))
print(id(b))
print(id(c))

print('\nlist')
a = [1,2,3]

b = [1,2,3]

c = a

print(id(a))
print(id(b))
print(id(c))
