class Person:
    def __init__(self,name='',gender='',age=0):
        self.Name=name
        self.Gender=gender
        self.Age=age

    def setName(self,name):
        self.Name=name

    def setGender(self,gender):
        self.Gender=gender

    def setAge(self,age):
        self.Age=age
