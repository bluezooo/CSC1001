from System import System

system=System()
system.readStudentDict('6-Course Sytem/student.txt')
system.readStaffDict('6-Course Sytem/staff.txt')
system.show()
system.generateFile()
